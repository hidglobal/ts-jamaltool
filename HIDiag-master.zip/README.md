#HID Diagnostic Tool
{Under development}

HID Authentication Server, AaaS, and Appliance Diagnostic tool.